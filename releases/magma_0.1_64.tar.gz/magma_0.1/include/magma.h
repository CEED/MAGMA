/*
    -- MAGMA (version 0.1) --
       Univ. of Tennessee, Knoxville
       Univ. of California, Berkeley
       Univ. of Colorado, Denver
       June 2009
*/

#ifndef _PLASMA_
#define _PLASMA_

#include "auxiliary.h"

/* ////////////////////////////////////////////////////////////////////////////
   -- MAGMA function definitions
*/
int magma_spotrf(char *, int *, float *, int *, float *, int *);
int magma_spotrf_gpu(char *, int *, float *, int *, float *, int *);
int magma_slarfb(int, int, int *, float *, int *, float *,
                 int *, float *, int *, float *, int *);
int magma_sgeqrf(int *, int *, float *, int  *,  float  *,
		 float *, int *, float *, int *);
int magma_sgeqrf_gpu(int *, int *, float *, int  *,  float  *,
		     float *, int *, float *, int *);
int magma_sgetrf(int *, int *, float *, int *, int *, float *, float *, int *);
int magma_sgetrf_gpu(int *, int *, float *, int *, int *, float *, int *);

int magma_dpotrf(char *, int *, double *, int *, double *, int *);
int magma_dpotrf_gpu(char *, int *, double *, int *, double *, int *);
int magma_dlarfb(int, int, int *, double *, int *, double *,
                 int *, double *, int *, double *, int *);
int magma_dgeqrf(int *, int *, double *, int  *,  double  *,
		 double *, int *, double *, int *);
int magma_dgeqrf_gpu(int *, int *, double *, int  *, double  *,
		     double *, int *, double *, int *);
int magma_dgetrf(int *, int *, double *, int *, int *, double*, double*, int*);
int magma_dgetrf_gpu(int *, int *, double *, int *, int *, double *, int *);

int magma_cpotrf(char *, int *, float2 *, int *, float2 *, int *);
int magma_clarfb(int, int, int *, float2 *, int *, float2 *,
                 int *, float2 *, int *, float2 *, int *);
int magma_cgeqrf(int *, int *, float2 *, int  *,  float2  *,
                 float2 *, int *, float2 *, int *);

/* ////////////////////////////////////////////////////////////////////////////
   -- LAPACK Externs used in MAGMA
*/
extern "C" void strsm_(char *, char *, char *, char *,
		       int *, int *, float *, float *, int *, float *, int*);
extern "C" void sgemm_(char *, char *, int *, int *, int *, float *,
		       float *, int *, float *, int *, float *,
		       float *, int *);
extern "C" void saxpy_(int *, float *, float *, int *, float *, int *);
extern "C" void ssyrk_(char *, char *, int *, int *, float *, float *,
		       int *, float *, float *, int *);
extern "C" int strmm_(char *, char *, char *, char *,
                      int *, int *, float *, float *, int *, float *, int *);
extern "C" int slaswp_(int *, float *, int *, int *, int *, int *, int *);

extern "C" float snrm2_(const int, const float *, const int);
extern "C" float slange_(char *norm, int *, int *, float *, int *, float *);

extern "C" int spotrf_(char *uplo, int *n, float *a, int *lda, int *info);
extern "C" int spotf2_(char *, int *, float *, int *, int *);
extern "C" int sgeqrf_(int*,int*,float *,int*,float *,float *,int *,int *);
extern "C" int slarft_(char *, char *, int *, int *, float *, int *, float *,
		       float *, int *);
extern "C" int sgetrf_(int *, int *, float *, int *, int *, int *);

extern "C" int slaset_(char *,int *,int *,float *,float *,float *a,int *);
extern "C" float slamch_(char *);
extern "C" float slansy_(char *, char *, int *, float *, int *, float *);
extern "C" int slacpy_(char *, int *, int *, float *, int *, float *, int *);
extern "C" int sorgqr_(int *, int *, int *, float *, int *, float *, 
		       float *, int *, int *);

extern "C" void caxpy_(int *, float2 *, float2 *, int *, float2 *, int *);
extern "C" int cpotrf_(char *uplo, int *n, float2 *a, int *lda, int *info);
extern "C" int cgeqrf_(int*,int*,float2 *,int*,float2 *,float2 *,int *,int *);
extern "C" int clarft_(char *, char *, int *, int *, float2 *, int *, float2 *,
                       float2 *, int *);
extern "C" int cgetrf_(int *, int *, float2 *, int *, int *, int *);

extern "C" float clange_(char *norm, int *, int *, float2 *, int *, float *);


extern "C" void dtrsm_(char *, char *, char *, char *,
		       int *, int *, double *, double *, int *, double *,int*);
extern "C" void dgemm_(char *, char *, int *, int *, int *, double *,
		       double *, int *, double *, int *, double *,
		       double *, int *);
extern "C" void daxpy_(int *, double *, double *, int *, double *, int *);
extern "C" void dsyrk_(char *, char *, int *, int *, double *, double *,
		       int *, double *, double *, int *);
extern "C" int dtrmm_(char *, char *, char *, char *, int *, int *, 
		      double *, double *, int *, double *, int *);
extern "C" int dlaswp_(int *, double *, int *, int *, int *, int *, int *);

extern "C" double dnrm2_(int *, double *, int *);
extern "C" double dlange_(char *norm, int *, int *, double *, int *, double *);

extern "C" int dpotrf_(char *uplo, int *n, double *a, int *lda, int *info);
extern "C" int dpotf2_(char *, int *, double *, int *, int *);
extern "C" int dgeqrf_(int*,int*,double *,int*,double *,double *,int *,int *);
extern "C" int dgetrf_(int *, int *, double *, int *, int *, int *);
extern "C" int dlarft_(char *, char *, int *, int *, double *, int *, double *,
		       double *, int *);
extern "C" int dlaset_(char *,int *,int *,double *,double *,double *a,int *);
extern "C" double dlamch_(char *);
extern "C" double dlansy_(char *, char *, int *, double *, int *, double *);
extern "C" int dlacpy_(char *, int *, int *, double *, int *, double *, int *);
extern "C" int dorgqr_(int *, int *, int *, double *, int *, double *, 
		       double *, int *, int *);

extern "C" long int lsame_(char *, char *);

#endif
