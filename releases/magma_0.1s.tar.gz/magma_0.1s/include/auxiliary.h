/*
    -- MAGMA (version 0.1) --
       Univ. of Tennessee, Knoxville
       Univ. of California, Berkeley
       Univ. of Colorado, Denver
       June 2009
*/

#ifndef _MAGMA_AUXILIARY_
#define _MAGMA_AUXILIARY_

int magma_get_spotrf_nb(int m);
int magma_get_sgeqrf_nb(int m);
int magma_get_sgetrf_nb(int m);

int magma_get_dpotrf_nb(int m);
int magma_get_dgeqrf_nb(int m);
int magma_get_dgetrf_nb(int m);

void start_timer(unsigned int &timer);
void end_timer(unsigned int &timer);

void spanel_to_q(int ib, float *a, int lda, float *work);
void sq_to_panel(int ib, float *a, int lda, float *work);

int sqrt02(int *m, int *n, int *k, float *a, float *af, float *q,
	   float *r__, int *lda, float *tau, float *work,
	   int *lwork, float *rwork, float *result);

void cpanel_to_q(int ib, float2 *a, int lda, float2 *work);
void cq_to_panel(int ib, float2 *a, int lda, float2 *work);

void dpanel_to_q(int ib, double *a, int lda, double *work);
void dq_to_panel(int ib, double *a, int lda, double *work);

int dqrt02(int *m, int *n, int *k, double *a, double *af, double *q,
	   double *r__, int *lda, double *tau, double *work,
	   int *lwork, double *rwork, double *result);

#endif
